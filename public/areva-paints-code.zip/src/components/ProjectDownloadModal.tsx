import React, { useState } from 'react';
import {
  Download,
  X,
  FileCode,
  FolderArchive,
  Terminal,
  Check,
  Copy,
  Layers,
  Server,
  Code2,
  ExternalLink,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';

interface ProjectDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProjectDownloadModal: React.FC<ProjectDownloadModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'github'>('overview');
  const [downloading, setDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleDownloadZip = () => {
    setDownloading(true);
    setDownloadSuccess(false);

    // Create an invisible anchor tag to trigger browser download
    const link = document.createElement('a');
    link.href = '/api/project/download';
    link.download = 'areva-paints-fullstack.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => {
      setDownloading(false);
      setDownloadSuccess(true);
    }, 1800);
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCommand(id);
    setTimeout(() => setCopiedCommand(null), 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-stone-950/75 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="px-6 sm:px-8 py-5 border-b border-stone-100 bg-stone-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-500 to-rose-600 flex items-center justify-center text-white shadow-md">
              <FolderArchive className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-extrabold text-xl text-white tracking-tight">
                  Download Project Source Code
                </h3>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  Full-Stack Ready
                </span>
              </div>
              <p className="text-xs text-stone-400 mt-0.5">
                Complete React 19 + TypeScript + Express Backend + WebXR AR Studio codebase
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-white hover:bg-stone-800 transition-colors focus:outline-none"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-stone-200 bg-stone-50 px-6 sm:px-8 pt-3 gap-2">
          <button
            onClick={() => setActiveTab('overview')}
            className={`pb-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-all cursor-pointer ${
              activeTab === 'overview'
                ? 'border-amber-700 text-amber-900 bg-white/70 rounded-t-xl shadow-xs'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            📦 Download & Quick Run
          </button>
          <button
            onClick={() => setActiveTab('github')}
            className={`pb-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'github'
                ? 'border-amber-700 text-amber-900 bg-white/70 rounded-t-xl shadow-xs'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <span>🐙 Push to GitHub Repository</span>
            <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-bold">
              Easy
            </span>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-6 text-stone-900">
          {activeTab === 'overview' ? (
            <>
              {/* Main Action Banner */}
              <div className="relative p-6 sm:p-7 rounded-2xl bg-gradient-to-br from-amber-50 via-stone-50 to-orange-50 border border-amber-200/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-6">
                <div className="space-y-2 text-center sm:text-left">
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-800 flex items-center gap-1.5 justify-center sm:justify-start">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                    Production Archive
                  </span>
                  <h4 className="text-xl sm:text-2xl font-display font-black text-stone-950">
                    areva-paints-fullstack.zip
                  </h4>
                  <p className="text-xs sm:text-sm text-stone-600 max-w-md">
                    Contains complete source tree (`src/`, `public/`, `server.ts`, `package.json`, `tsconfig.json`, `vite.config.ts`, `README.md`) ready to run with <code className="text-amber-800 bg-amber-100/60 px-1.5 py-0.5 rounded font-mono text-xs">npm install && npm run dev</code>.
                  </p>
                </div>

                <div className="shrink-0 w-full sm:w-auto flex flex-col items-center gap-2">
                  <a
                    href="/areva-paints-fullstack.zip"
                    download="areva-paints-fullstack.zip"
                    onClick={() => {
                      setDownloadSuccess(true);
                      setTimeout(() => setDownloadSuccess(false), 3500);
                    }}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-2xl bg-stone-950 hover:bg-amber-800 text-white font-bold text-sm shadow-lg hover:shadow-xl transition-all duration-200 active:scale-95 cursor-pointer text-center no-underline"
                  >
                    {downloadSuccess ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-400" />
                        <span>Downloading Started!</span>
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4 text-amber-400" />
                        <span>Download Full Project (.ZIP)</span>
                      </>
                    )}
                  </a>
                  
                  <div className="flex items-center gap-2 text-[11px] text-stone-500 font-medium">
                    <span className="inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md font-semibold">
                      <ShieldCheck className="w-3 h-3 text-emerald-600" />
                      Windows 10/11 & Mac Verified
                    </span>
                    <span>•</span>
                    <a
                      href="/api/project/download"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-amber-700 hover:underline inline-flex items-center gap-0.5"
                    >
                      <span>Direct API Stream</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              </div>

              {/* Windows Extraction Guide Card */}
              <div className="p-5 rounded-2xl bg-gradient-to-r from-blue-50/90 via-sky-50/70 to-indigo-50/80 border border-blue-200/90 text-xs text-stone-800 space-y-3 shadow-xs">
                <div className="flex items-center justify-between">
                  <div className="font-bold flex items-center gap-2 text-blue-950 text-sm">
                    <span className="w-6 h-6 rounded-lg bg-blue-600 text-white flex items-center justify-center text-xs font-black shadow-xs">⊞</span>
                    <span>Windows 10 / 11 Extraction Guide</span>
                  </div>
                  <span className="text-[11px] font-semibold text-blue-700 bg-white/80 border border-blue-200 px-2 py-0.5 rounded-full">
                    Windows Explorer Ready
                  </span>
                </div>

                <p className="text-stone-600 leading-relaxed text-xs">
                  This archive has been packaged with <strong>explicit Windows MS-DOS directory records</strong> and is enclosed in an <code className="bg-blue-100 text-blue-900 px-1 py-0.5 rounded font-mono font-bold">areva-paints-fullstack/</code> folder to prevent Windows <em>"Compressed (zipped) Folder is invalid"</em> or extraction errors.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                  {/* Method A: Windows Explorer */}
                  <div className="bg-white p-3.5 rounded-xl border border-blue-200/80 space-y-1.5 shadow-xs">
                    <div className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                      <span className="w-4 h-4 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold flex items-center justify-center">A</span>
                      <span>Method 1: Windows File Explorer</span>
                    </div>
                    <ol className="text-[11px] text-stone-600 space-y-1 list-decimal list-inside pl-1">
                      <li>Locate <code className="font-mono text-stone-800 bg-stone-100 px-1 py-0.2 rounded">areva-paints-fullstack.zip</code> in Downloads.</li>
                      <li>Right-click the zip file and click <strong>Extract All...</strong></li>
                      <li>Click <strong>Extract</strong> to unpack cleanly.</li>
                    </ol>
                  </div>

                  {/* Method B: PowerShell 1-Liner */}
                  <div className="bg-white p-3.5 rounded-xl border border-blue-200/80 space-y-1.5 shadow-xs flex flex-col justify-between">
                    <div>
                      <div className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                        <span className="w-4 h-4 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold flex items-center justify-center">B</span>
                        <span>Method 2: PowerShell Instant Unzip</span>
                      </div>
                      <p className="text-[11px] text-stone-600 mt-1">
                        Run this in PowerShell inside your Downloads folder:
                      </p>
                    </div>
                    <div className="bg-stone-950 text-stone-100 p-2 rounded-lg font-mono text-[11px] flex items-center justify-between border border-stone-800">
                      <span className="text-sky-300 truncate mr-2">Expand-Archive .\areva-paints-fullstack.zip -Dest .</span>
                      <button
                        onClick={() => copyToClipboard('Expand-Archive -Path .\\areva-paints-fullstack.zip -DestinationPath .', 'ps-unzip')}
                        className="text-stone-400 hover:text-white p-1 cursor-pointer shrink-0"
                        title="Copy PowerShell command"
                      >
                        {copiedCommand === 'ps-unzip' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Direct File Path / URL Box */}
              <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200/90 text-xs text-stone-800 space-y-2">
                <div className="font-bold flex items-center gap-2 text-stone-900">
                  <FolderArchive className="w-4 h-4 text-amber-700" />
                  <span>Exact File Location in Project:</span>
                </div>
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2 bg-white p-2.5 rounded-xl border border-amber-300 font-mono text-[11px] text-stone-800">
                  <span className="truncate selection:bg-amber-100">
                    /public/areva-paints-fullstack.zip
                  </span>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => copyToClipboard(window.location.origin + '/areva-paints-fullstack.zip', 'direct-url')}
                      className="px-2.5 py-1 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 font-sans font-semibold text-[11px] flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      {copiedCommand === 'direct-url' ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span>Copied Link!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy Full URL</span>
                        </>
                      )}
                    </button>
                    <a
                      href="/areva-paints-fullstack.zip"
                      target="_blank"
                      download="areva-paints-fullstack.zip"
                      className="px-2.5 py-1 rounded-lg bg-amber-800 hover:bg-amber-900 text-white font-sans font-bold text-[11px] flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <Download className="w-3 h-3" />
                      <span>Direct Download</span>
                    </a>
                  </div>
                </div>
                <p className="text-[11px] text-stone-600">
                  If your browser preview blocks downloads inside the iframe, click <strong>"Direct Download"</strong> or paste the copied URL into a new browser tab to download immediately.
                </p>
              </div>

              {/* Quick Terminal Setup Instructions */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500 flex items-center gap-1.5">
                    <Terminal className="w-4 h-4 text-stone-700" />
                    Quick Terminal Run Instructions (Windows / Mac / Linux)
                  </h4>
                  <span className="text-xs text-stone-500 font-mono">Node.js 18+ required</span>
                </div>

                <div className="bg-stone-950 text-stone-100 rounded-2xl p-4 sm:p-5 font-mono text-xs space-y-3 border border-stone-800 shadow-inner">
                  <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                    <span className="text-stone-400 text-[11px]"># 1. Extract ZIP & Install all dependencies</span>
                    <button
                      onClick={() => copyToClipboard('npm install', 'c1')}
                      className="text-stone-400 hover:text-white transition-colors p-1 cursor-pointer"
                      title="Copy command"
                    >
                      {copiedCommand === 'c1' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                  <div className="text-emerald-400 font-semibold selection:bg-stone-700">npm install</div>

                  <div className="flex items-center justify-between pt-2 pb-2 border-b border-stone-800">
                    <span className="text-stone-400 text-[11px]"># 2. Run Full-Stack Express Server + Vite dev mode</span>
                    <button
                      onClick={() => copyToClipboard('npm run dev', 'c2')}
                      className="text-stone-400 hover:text-white transition-colors p-1 cursor-pointer"
                      title="Copy command"
                    >
                      {copiedCommand === 'c2' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                  <div className="text-amber-300 font-semibold selection:bg-stone-700">npm run dev</div>

                  <div className="flex items-center justify-between pt-2 pb-2 border-b border-stone-800">
                    <span className="text-stone-400 text-[11px]"># 3. Production Build & Static Output</span>
                    <button
                      onClick={() => copyToClipboard('npm run build && npm start', 'c3')}
                      className="text-stone-400 hover:text-white transition-colors p-1 cursor-pointer"
                      title="Copy command"
                    >
                      {copiedCommand === 'c3' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                  <div className="text-sky-300 font-semibold selection:bg-stone-700">npm run build && npm start</div>
                </div>
              </div>

              {/* Architecture Blueprint Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Box 1: Backend */}
                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200/80 space-y-2">
                  <div className="flex items-center gap-2 text-stone-900 font-bold text-sm">
                    <Server className="w-4 h-4 text-amber-700" />
                    <span>Backend API (`server.ts`)</span>
                  </div>
                  <ul className="text-xs text-stone-600 space-y-1.5 list-disc list-inside">
                    <li>Node Express 4.x runtime</li>
                    <li>8 REST endpoints (Health, Catalog, Estimates, Dealers)</li>
                    <li>Dynamic archiver ZIP engine</li>
                    <li>Vite middlewares integration</li>
                  </ul>
                </div>

                {/* Box 2: Frontend */}
                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200/80 space-y-2">
                  <div className="flex items-center gap-2 text-stone-900 font-bold text-sm">
                    <Code2 className="w-4 h-4 text-amber-700" />
                    <span>Modern Frontend</span>
                  </div>
                  <ul className="text-xs text-stone-600 space-y-1.5 list-disc list-inside">
                    <li>React 19 + TypeScript (Strict)</li>
                    <li>Tailwind CSS v4 with design tokens</li>
                    <li>Hero Slider & Color Ticker</li>
                    <li>Room Interior Visualizer Studio</li>
                  </ul>
                </div>

                {/* Box 3: AR & Calculator */}
                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200/80 space-y-2">
                  <div className="flex items-center gap-2 text-stone-900 font-bold text-sm">
                    <Layers className="w-4 h-4 text-amber-700" />
                    <span>WebXR AR & Math Engine</span>
                  </div>
                  <ul className="text-xs text-stone-600 space-y-1.5 list-disc list-inside">
                    <li>60fps Live Camera recoloring</li>
                    <li>Coating formulation system dropdown</li>
                    <li>Net area math & can pack distribution</li>
                    <li>Regional dealer routing & dispatch</li>
                  </ul>
                </div>
              </div>

              {/* File Manifest List */}
              <div className="border border-stone-200 rounded-2xl p-4 bg-stone-50/50 space-y-2">
                <h5 className="text-xs font-bold uppercase tracking-wider text-stone-700 flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-amber-700" />
                  Included Source Manifest
                </h5>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs font-mono text-stone-600">
                  <div className="p-2 rounded bg-white border border-stone-200 truncate">📄 server.ts</div>
                  <div className="p-2 rounded bg-white border border-stone-200 truncate">📁 src/components/</div>
                  <div className="p-2 rounded bg-white border border-stone-200 truncate">📁 src/data/</div>
                  <div className="p-2 rounded bg-white border border-stone-200 truncate">📄 src/App.tsx</div>
                  <div className="p-2 rounded bg-white border border-stone-200 truncate">📄 package.json</div>
                  <div className="p-2 rounded bg-white border border-stone-200 truncate">📄 tsconfig.json</div>
                  <div className="p-2 rounded bg-white border border-stone-200 truncate">📄 vite.config.ts</div>
                  <div className="p-2 rounded bg-white border border-stone-200 truncate">📄 index.html</div>
                  <div className="p-2 rounded bg-white border border-stone-200 truncate">📄 README.md</div>
                </div>
              </div>
            </>
          ) : (
            /* Push to GitHub Tab */
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-stone-900 to-stone-800 text-white p-5 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 border border-stone-700">
                <div className="space-y-1 text-center sm:text-left">
                  <h4 className="font-display font-bold text-lg text-white flex items-center gap-2 justify-center sm:justify-start">
                    <span>How to Push to your GitHub Repository</span>
                  </h4>
                  <p className="text-xs text-stone-300">
                    Follow these 4 simple steps to push this full codebase to your personal or organization GitHub repo.
                  </p>
                </div>
                <button
                  onClick={handleDownloadZip}
                  className="shrink-0 px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download ZIP First</span>
                </button>
              </div>

              {/* Step 1 */}
              <div className="border border-stone-200 rounded-2xl p-5 bg-white space-y-3">
                <div className="flex items-center gap-2 text-stone-900 font-bold text-sm">
                  <span className="w-6 h-6 rounded-full bg-amber-800 text-white text-xs flex items-center justify-center font-bold">1</span>
                  <span>Create a New Repository on GitHub</span>
                </div>
                <p className="text-xs text-stone-600 leading-relaxed pl-8">
                  Go to <a href="https://github.com/new" target="_blank" rel="noreferrer" className="text-amber-700 underline font-semibold inline-flex items-center gap-1">github.com/new <ExternalLink className="w-3 h-3" /></a>, enter a repository name (e.g., <code className="bg-stone-100 px-1 py-0.5 rounded text-stone-800 font-mono">areva-paints</code>), leave "Initialize with README" unchecked (since this project already includes a full README.md), and click <strong>Create repository</strong>.
                </p>
              </div>

              {/* Step 2 */}
              <div className="border border-stone-200 rounded-2xl p-5 bg-white space-y-3">
                <div className="flex items-center gap-2 text-stone-900 font-bold text-sm">
                  <span className="w-6 h-6 rounded-full bg-amber-800 text-white text-xs flex items-center justify-center font-bold">2</span>
                  <span>Extract the ZIP and Open Terminal in Project Directory</span>
                </div>
                <p className="text-xs text-stone-600 leading-relaxed pl-8">
                  Extract the downloaded <code className="bg-stone-100 px-1 py-0.5 rounded text-stone-800 font-mono">areva-paints-fullstack.zip</code> file onto your machine, and open Terminal / Command Prompt inside the extracted folder:
                </p>
                <div className="pl-8">
                  <div className="bg-stone-950 text-stone-100 p-3 rounded-xl font-mono text-xs flex items-center justify-between border border-stone-800">
                    <span className="text-emerald-400">cd areva-paints-fullstack</span>
                    <button
                      onClick={() => copyToClipboard('cd areva-paints-fullstack', 'gh-cd')}
                      className="text-stone-400 hover:text-white p-1 cursor-pointer"
                    >
                      {copiedCommand === 'gh-cd' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
              </div>

              {/* Step 3 */}
              <div className="border border-stone-200 rounded-2xl p-5 bg-white space-y-3">
                <div className="flex items-center gap-2 text-stone-900 font-bold text-sm">
                  <span className="w-6 h-6 rounded-full bg-amber-800 text-white text-xs flex items-center justify-center font-bold">3</span>
                  <span>Initialize Git and Commit the Files</span>
                </div>
                <p className="text-xs text-stone-600 leading-relaxed pl-8">
                  Run the following commands to initialize git and stage all project files:
                </p>
                <div className="pl-8 space-y-2">
                  <div className="bg-stone-950 text-stone-100 p-3 rounded-xl font-mono text-xs space-y-2 border border-stone-800">
                    <div className="flex items-center justify-between">
                      <span className="text-emerald-400">git init</span>
                      <button onClick={() => copyToClipboard('git init', 'g-init')} className="text-stone-400 hover:text-white p-1 cursor-pointer">
                        {copiedCommand === 'g-init' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-emerald-400">git add .</span>
                      <button onClick={() => copyToClipboard('git add .', 'g-add')} className="text-stone-400 hover:text-white p-1 cursor-pointer">
                        {copiedCommand === 'g-add' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-amber-300">git commit -m "feat: initial commit of Areva Paints fullstack application"</span>
                      <button onClick={() => copyToClipboard('git commit -m "feat: initial commit of Areva Paints fullstack application"', 'g-commit')} className="text-stone-400 hover:text-white p-1 cursor-pointer">
                        {copiedCommand === 'g-commit' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sky-300">git branch -M main</span>
                      <button onClick={() => copyToClipboard('git branch -M main', 'g-branch')} className="text-stone-400 hover:text-white p-1 cursor-pointer">
                        {copiedCommand === 'g-branch' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Step 4 */}
              <div className="border border-stone-200 rounded-2xl p-5 bg-white space-y-3">
                <div className="flex items-center gap-2 text-stone-900 font-bold text-sm">
                  <span className="w-6 h-6 rounded-full bg-amber-800 text-white text-xs flex items-center justify-center font-bold">4</span>
                  <span>Link Remote and Push to GitHub</span>
                </div>
                <p className="text-xs text-stone-600 leading-relaxed pl-8">
                  Replace <code className="bg-amber-100 text-amber-900 px-1 py-0.5 rounded font-mono font-bold">&lt;YOUR-USERNAME&gt;</code> and <code className="bg-amber-100 text-amber-900 px-1 py-0.5 rounded font-mono font-bold">&lt;YOUR-REPO-NAME&gt;</code> with your GitHub details:
                </p>
                <div className="pl-8 space-y-2">
                  <div className="bg-stone-950 text-stone-100 p-3 rounded-xl font-mono text-xs space-y-2 border border-stone-800">
                    <div className="flex items-center justify-between">
                      <span className="text-amber-300">git remote add origin https://github.com/&lt;YOUR-USERNAME&gt;/&lt;YOUR-REPO-NAME&gt;.git</span>
                      <button onClick={() => copyToClipboard('git remote add origin https://github.com/<YOUR-USERNAME>/<YOUR-REPO-NAME>.git', 'g-remote')} className="text-stone-400 hover:text-white p-1 cursor-pointer">
                        {copiedCommand === 'g-remote' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-emerald-400 font-bold">git push -u origin main</span>
                      <button onClick={() => copyToClipboard('git push -u origin main', 'g-push')} className="text-stone-400 hover:text-white p-1 cursor-pointer">
                        {copiedCommand === 'g-push' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                </div>
                <div className="pl-8">
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Your complete code is now live on GitHub! Team members can clone it and run <code className="font-mono font-bold">npm install && npm run dev</code>.</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-6 sm:px-8 py-4 bg-stone-100 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-stone-600">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Ready for local development and cloud container deployment.</span>
          </div>
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="w-full sm:w-auto px-4 py-2 rounded-xl text-stone-700 hover:text-stone-950 hover:bg-stone-200 transition-colors font-medium"
            >
              Close
            </button>
            <a
              href="/areva-paints-fullstack.zip"
              download="areva-paints-fullstack.zip"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-amber-800 hover:bg-amber-900 text-white font-bold shadow-xs active:scale-95 transition-all text-center no-underline cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download ZIP (3.8 MB)</span>
            </a>
          </div>
        </div>

      </div>
    </div>
  );
};
